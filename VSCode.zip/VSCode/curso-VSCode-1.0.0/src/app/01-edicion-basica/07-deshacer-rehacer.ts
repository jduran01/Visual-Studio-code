/*
    Objetivo:
        Deshacer y rehacer el código
§
    Tips:
        ⌘ Z
        ⌘ ⇧ Z
        Ctrl +Z
        Ctrl + Shift + Z

*/






// Demo
// function holaMundo() {
//     return 'Saludos a todos!';
// }


