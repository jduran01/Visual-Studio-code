/*
    Objetivo:
        Comentar un bloque de código

    Tips:
        ⇧ ⌘ K
        Ctrl + Shift + K

    PRO:
        Seleccionar todas las ocurrencias de la selección
        ⇧ ⌘ L
        Ctrl + Shift + L
*/

let NoMeBorres = ':)';
let Borrame = ':(';

NoMeBorres = '1';
Borrame    = 'a';
NoMeBorres = '1';
Borrame    = 'a';


// Resultado final (sin los comentarios claro.)

// let NoMeBorres = ':)';

// NoMeBorres = '1';
// NoMeBorres = '1';
